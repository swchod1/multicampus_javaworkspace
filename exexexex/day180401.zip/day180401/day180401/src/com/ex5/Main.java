package com.ex5;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				
		Student stu = new Student("동양서울대학교", "전산정보학과", "20132222");
		
		
		stu.write();
		

	}

}

