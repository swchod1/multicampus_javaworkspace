package com.ex5;

/*-클래스 Person: 
	필드: 이름, 나이, 주소 선언*/

public class Person {
	
	
	
	String name = "김다정"; // 이름
	int age = 20; // 주소
	String add = "서울시 관악구"; // 나이
	

	
	
	
	

}
