package com.ex2;

public class Dan {
	
	///////////////////// 3차(원금 입력+클래스 쪼개보기+복리) ///////////////////////
	
	private int won;
	private int year;
	

	
	public int getWon() {
		return won;
	}

	public void setWon(int won) {
		this.won = won;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}


	
	
	

}
