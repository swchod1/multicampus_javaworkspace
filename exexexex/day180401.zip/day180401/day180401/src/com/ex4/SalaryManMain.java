package com.ex4;

public class SalaryManMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(new SalaryMan().getAnnualGross()); 
		System.out.println(new SalaryMan(2_000_000).getAnnualGross());

	}

}
