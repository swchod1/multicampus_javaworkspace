package exam;

/*
 * 2차원 배열을 이용하여 구현하시오.
 * 
 * 1 2 3 4 5
 * 10 9 8 7 6
 * 11 12 13 14 15
 * 20 19 18 17 16
 * 
 */



public class Quiz1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i, j, k;
		int aa[][] = new int [4][5];
		
		
		/*for (i = 0, k = 0; i < aa.length; k += 10, i++) {
			for (j = 0; j < aa[i].length; j++) {
				if (i % 2 != 0) {
					aa[i][j] = k - j + 5;
				} else {					
					aa[i][j] = k + j + 1;
				}
			}
		}*/
		
		for (i = 0; i < aa.length; i ++) {
			for ( j = 0; j < aa[i].length; j++) {
				if((j+1) % 5 == 0) {
					j = j+10;
				}
			}
		}
		
		
		
		for (i = 0 ; i < aa.length ; i++) {
			for (j = 0; j < aa[i].length; j++) {
				System.out.printf(aa[i][j]+"\t");
			}
			System.out.println();
		}
		

	}

}
