package exam;

public class Quiz4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i, j;
		int aa[][] = new int [4][5];
		
		
		for (i = 0; i < aa.length; i ++) {
			for ( j = 0; j < aa[i].length; j++) {
				aa[i][j] =  i+4*j+1;
			}
		}
			
		for (i = 0 ; i < aa.length ; i++) {
			for (j = 0; j < aa[i].length; j++) {
				System.out.printf(aa[i][j]+"\t");
			}
			System.out.println();
		}
		
		

	}

}
