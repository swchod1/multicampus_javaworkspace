package exam;

/*
 * 2차원 배열을 이용하여 구현하시오.
 * 20 16 12 8 4
 * 19
 * 
 */



public class Quiz3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int i, j;
		int aa[][] = new int [4][5];
		
		
		for (i = 0; i < aa.length; i ++) {
			for ( j = 0; j < aa[i].length; j++) {
				aa[i][j] =  aa.length*aa[i].length-i-4*j;
			}
		}
			
		for (i = 0 ; i < aa.length ; i++) {
			for (j = 0; j < aa[i].length; j++) {
				System.out.printf(aa[i][j]+"\t");
			}
			System.out.println();
		}
		
		
		

	}

}
