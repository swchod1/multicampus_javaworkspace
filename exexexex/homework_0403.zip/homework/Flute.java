package com.homework;

public class Flute extends Instrument {
	
	@Override
	void play() {
		// TODO Auto-generated method stub
		
		System.out.println("Flute : play() 호출됨");
		
	}
	@Override
	void volumeUp() {
		// TODO Auto-generated method stub
		
		System.out.println("Flute : volumeUp() 호출됨");
		
	}
	@Override
	void volumeDown() {
		// TODO Auto-generated method stub
		
		System.out.println("Flute : volumeDown() 호출됨");
		
	}

}
