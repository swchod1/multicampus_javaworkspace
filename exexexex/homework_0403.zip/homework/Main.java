package com.homework;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Piano piano = new Piano();
		Flute flute = new Flute();
		
		piano.volumeUp();
		piano.volumeDown();
		piano.play();
		
		flute.volumeUp();
		flute.volumeDown();
		flute.play();
		
		

	}

}
