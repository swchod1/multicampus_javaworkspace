package com.test.exception;

public class MyExceptionTest {
	
	public static void main(String[] args) 
			throws MyException {
		throw new MyException();
	}
}






