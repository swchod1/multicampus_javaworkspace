package com.test.human;

public class HumanTest {
	
	public static void main(String[] args) {
		new UI().start();
	}
}
